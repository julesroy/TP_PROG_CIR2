#include <iostream>
using namespace std;
#include "exo1.hpp"

int main() {
	return 0;
}